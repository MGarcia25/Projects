package test.Poker2.poker.one.testing;

//import static org.junit.jupiter.api.Assertions.*;
import org.junit.Assert;
import org.junit.Test;

public class PokerFrameDumbTest {
    @Test
    public void testBooleanCheck(){
        PokerCards card1 = new PokerCards(PokerCards.Suit.Spades, PokerCards.Number.Ace );
        PokerCards card2 = new PokerCards(PokerCards.Suit.Hearts, PokerCards.Number.Nine);



        //test for card 1
        PokerCards.Suit expected1Suit = PokerCards.Suit.Spades;
        PokerCards.Number expected1Num = PokerCards.Number.Ace;

        PokerCards.Suit actual1Suit = card1.getSuit();
        PokerCards.Number actual1Num = card1.getNumber();


        //test for card 2
        PokerCards.Suit expected2Suit = PokerCards.Suit.Hearts;
        PokerCards.Number expected2Num = PokerCards.Number.Nine;

        PokerCards.Suit actual2Suit = card2.getSuit();
        PokerCards.Number actual2Num = card2.getNumber();


        Assert.assertEquals("Suits did not match for First Card", expected1Suit, actual1Suit);
        Assert.assertEquals("Numbers did not match for First Card", expected1Num, actual1Num);
        Assert.assertEquals("Suits did not match for Second Card", expected2Suit, actual2Suit);
        Assert.assertEquals("Numbers did not match for Second Card", expected2Num, actual2Num);

    }

}