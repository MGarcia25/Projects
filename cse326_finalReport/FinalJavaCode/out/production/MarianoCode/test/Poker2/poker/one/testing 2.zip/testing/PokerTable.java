package test.Poker2.poker.one.testing;

import test.Poker2.poker.one.testing.Poker;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class PokerTable extends JComponent {
    public Poker poker;
    private int numPlay = 0;
    public static int cardsRevealNum = 0;
    private static boolean gameOver;
    //PopUp window;
    String path = "Poker\\GreenTable.jpg";

    /*public String[] getPID(){

    }*/


    public boolean getGameOver(){
        return gameOver;
    }

    //constructor
    //public PokerTable(int players, PokerCards card1, PokerCards card2){
    public PokerTable(int players){
        numPlay = players;
        setPreferredSize(new Dimension(1000,720));
        addMouseListener(new PlayHandler());
        gameOver = false;
        repaint();
        poker = new Poker(numPlay);
        //freeCall();
    }



    private class PlayHandler extends MouseAdapter {
        @Override
        public void mouseClicked(MouseEvent event) {
            //boolean bool = cardReveal(); //calls cardReveal where the number of cards revealed is incremented
            System.out.println("PokerTable 47");
            /*if (bool == true) {
                if (cardsRevealNum == 4) {  //once all cards are reveal, start a new game
                    gameOver = true;
                    repaint();
                } else {
                    gameOver = false;
                    repaint();
                }
            }*/

        }
    }



    public static boolean cardReveal(){
        cardsRevealNum++; // clicks to see the next reveal
        return false;
    }

    public void resetGame(){
        //shuffle cards here
        //this.poker;
        gameOver = false;
        repaint();
    }


    public void paintComponent(Graphics g){
        super.paintComponents(g);

        //BufferedImage backCard = ImageIO.read(new File("/images/Card_BACK.png"));ce
        //BufferedImage backCard = ImageIO.read(new File("images/Card_BACK.png"));
        //Image backCard = Toolkit.getDefaultToolkit().getImage("testing/images/Card_BACK.png");

        try {
            Image backCard = ImageIO.read(getClass().getResource("/resources/images/Card_BACK.png"));
            g.drawImage(backCard,0,0,200,278,null);
            Image backCard2 = ImageIO.read(getClass().getResource("/resources/images/Card_BACK.png"));
            g.drawImage(backCard2,201,0,200,278,null);

            //PokerCards c1 = PokerFrameDumb.card1;
            //PokerCards c2 = PokerFrameDumb.card2;
            for (PokerCards c : PokerFrameDumb.deck.cards){
                if(c.toString().equals(PokerFrameDumb.card1.toString())){
                    PokerCards c1 = PokerFrameDumb.card1;
                    Image playerCard1 = ImageIO.read(getClass().getResource("/resources/images/" + c1 + ".png"));
                    g.drawImage(playerCard1,0,400,200,278,null);
                }
                if(c.toString().equals(PokerFrameDumb.card2.toString())){
                    PokerCards c2 = PokerFrameDumb.card2;
                    Image playerCard2 = ImageIO.read(getClass().getResource("/resources/images/" + c2 + ".png"));
                    g.drawImage(playerCard2,201,400,200,278,null);
                }
            }
            /*Image playerCard1 = ImageIO.read(getClass().getResource("/resources/images/" + c1 + ".png"));
            g.drawImage(playerCard1,0,300,200,278,null);
            //g.drawImage(playerCard11,201,300,200,278,null);
            Image playerCard2 = ImageIO.read(getClass().getResource("/resources/images/"));*/


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
