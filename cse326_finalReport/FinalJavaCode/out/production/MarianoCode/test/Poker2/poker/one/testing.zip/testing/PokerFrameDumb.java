package test.Poker2.poker.one.testing;

//import javafx.stage.Screen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PokerFrameDumb extends JFrame implements ActionListener {

    /**
     * Back ground/ table of the program
     * @invariant newGame button is not clicked
     */
    private PokerTable table;

    /**
     * Button used to begin calculations
     * @invariant calcButton is not clicked
     */
    public final JButton calcButton;

    /**
     * Page that asks user for input
     * @invariant askPage is available
     */
    public JFrame askPage;

    public JFrame helpFrame;


    /**
     * next page after user has inputted their selections
     * @invariant askPage has been completed and accepted
     */
    public JFrame pokerTableFrame;

    /**
     * Button generate a new game
     * @invariant newGame is not clicked
     */
    private JButton newGame;

    /**
     * Button that re asks the user to input new hand
     * @invariant newHand is not clicked
     */
    private JButton newHand;

    /**
     * Button that describes the hands to the user
     * @invariant helpButton is not clicked
     */
    private JButton helpButton;

    /**
     * Text field for user to input how many players
     * @invariant field is empty and incorrect
     */
    public JTextField textFieldPlayers = new JTextField();

    /**
     * Text field for user's first card suit
     * @invariant field is empty and incorrect
     */
    public JTextField card1TextFieldSuit = new JTextField();

    /**
     * Text field for user's second card suit
     * @invariant field is empty and incorrect
     */
    public JTextField card2TextFieldSuit = new JTextField();

    /**
     * Text field for user's first card number
     * @invariant field is empty and incorrect
     */
    public JTextField card1TextFieldNum = new JTextField();

    /**
     * Text field for user's second card number
     * @invariant field is empty and incorrect
     */
    public JTextField card2TextFieldNum = new JTextField();

    /**
     * input of users input of how many players
     * @invariant input is wrong
     */
    public static String numSelect;

    /**
     * input for user's first card number
     * @invariant field is empty and incorrect
     */
    public String card1Suit;

    /**
     * input for user's first card number
     * @invariant field is empty and incorrect
     */
    public String card1Num;

    /**
     * input for user's second card suit
     * @invariant field is empty and incorrect
     */
    public String card2Suit;

    /**
     * input for user's second card number
     * @invariant field is empty and incorrect
     */
    public String card2Num;

    /**
     * users first card
     * @invariant card is incorrect or a duplicate
     */
    public static PokerCards card1;

    /**
     * users second card
     * @invariant card is incorrect or a duplicate
     */
    public static PokerCards card2;

    /**
     * boolean check to ensure the first card is good
     */
    public static boolean card1Good;

    /**
     * boolean check to ensure the second card is good
     */
    public static boolean card2Good;


    //Initializing the deck and shuffling it

    /**
     * Returns string of numSelect
     * @return numSelect
     */
    public static String getNumSelect(){
        return numSelect;
    }

    public PokerDeck deck = new PokerDeck();

    /**
     *  Constructor of PokerFrameDumb
     */
    public PokerFrameDumb(){
        //table = new PokerTable(n);
        //pokerTableFrame.setVisible(false);
        askPage = new JFrame();
        askPage.setSize(1200,500);
        askPage.setLocationRelativeTo(null);
        String phcTitle = "Poker Hands Calculator";
        JLabel text = new JLabel(phcTitle, SwingConstants.CENTER);
        text.setFont(new Font("Serif", Font.BOLD, 44));
        askPage.add(text,BorderLayout.NORTH);
        askPage.setBackground(Color.pink);
        GridLayout gl = new GridLayout(10,2);

        calcButton = new JButton("Calculate");

        askPage.setLayout(gl);
        //JLabel title = new JLabel("Poker Hands Calculator");
        //askPage.add(title, BorderLayout.CENTER);
        JLabel blank = new JLabel();
        askPage.add(blank);
        JLabel askPlayers = new JLabel("How many Players? (2-9)");
        askPage.add(askPlayers);
        askPage.add(textFieldPlayers);
        textFieldPlayers.setFont(new Font("Cracked", Font.PLAIN,20));
        JLabel askcard1Suit = new JLabel("Please enter your first card's SUIT");
        askPage.add(askcard1Suit);
        askPage.add(card1TextFieldSuit);
        card1TextFieldSuit.setFont(new Font("Cracked", Font.PLAIN, 20));
        JLabel askcard1Num = new JLabel("Please enter your first card's NUMBER (in TEXT) with the first letter capitalized");
        askPage.add(askcard1Num);
        askPage.add(card1TextFieldNum);
        card1TextFieldNum.setFont(new Font("Cracked", Font.PLAIN, 20));
        JLabel askcard2Suit = new JLabel("Please enter your second card's SUIT");
        askPage.add(askcard2Suit);
        askPage.add(card2TextFieldSuit);
        card2TextFieldSuit.setFont(new Font("Cracked", Font.PLAIN, 20));
        JLabel askcard2Num = new JLabel("Please enter your second card's NUMBER (in TEXT) with the first letter capitalized");
        askPage.add(askcard2Num);
        askPage.add(card2TextFieldNum);
        card2TextFieldNum.setFont(new Font("Cracked", Font.PLAIN, 20));

        JLabel blank2 = new JLabel();


        askPage.add(blank2);
        calcButton.addActionListener(this);
        askPage.add(calcButton, BorderLayout.SOUTH);


        askPage.setVisible(true);
        askPage.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        pack();
    }


    /**
     * Once user clicks 'calculate' button, checks and assigns the cards of user
     * @param a
     * @pre calcButton is not clicked
     * @post calcButton is clicked
     */
    public void actionPerformed(ActionEvent a) {
        if(a.getSource() == calcButton){
            numSelect = textFieldPlayers.getText();
            card1Num = card1TextFieldNum.getText();
            card1Suit = card1TextFieldSuit.getText();
            card2Num = card2TextFieldNum.getText();
            card2Suit = card2TextFieldSuit.getText();
            System.out.println(card1Num);
            System.out.println(card1Suit);
            System.out.println(card2Num);
            System.out.println(card2Suit);

            if(!(numSelect.equals("2") || numSelect.equals("3")||numSelect.equals("4")||numSelect.equals("5")||numSelect.equals("6")||numSelect.equals("7")||numSelect.equals("8")||numSelect.equals("9"))){
                JFrame popUpError = new JFrame();
                JOptionPane.showMessageDialog(popUpError, "Incorrect Input, Range of Players: 2-9", "ERROR", JOptionPane.ERROR_MESSAGE);
            } else {
                if (card1Suit.equalsIgnoreCase("Diamonds")) {
                    try {
                        card1 = new PokerCards(PokerCards.Suit.Diamonds, PokerCards.Number.valueOf(card1Num));
                        System.out.println("Card 1 good to GO");
                        card1Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for First Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card1Suit.equalsIgnoreCase("Hearts")) {
                    try {
                        card1 = new PokerCards(PokerCards.Suit.Hearts, PokerCards.Number.valueOf(card1Num));
                        System.out.println("Card 1 good to GO");
                        card1Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for First Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card1Suit.equalsIgnoreCase("Spades")) {
                    try {
                        card1 = new PokerCards(PokerCards.Suit.Spades, PokerCards.Number.valueOf(card1Num));
                        System.out.println("Card 1 good to GO");
                        card1Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for First Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card1Suit.equalsIgnoreCase("Clubs")) {
                    try {
                        card1 = new PokerCards(PokerCards.Suit.Clubs, PokerCards.Number.valueOf(card1Num));
                        System.out.println("Card 1 good to GO");
                        card1Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for First Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JFrame popUpError2 = new JFrame();
                    JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, First Card's suit is incorrect! Please double check" +
                            " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    //askPage.repaint();
                }
                if (card2Suit.equalsIgnoreCase("Diamonds")) {
                    try {
                        card2 = new PokerCards(PokerCards.Suit.Diamonds, PokerCards.Number.valueOf(card2Num));
                        if (card1 == card2){
                            JFrame popUpError2 = new JFrame();
                            JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                    " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                        System.out.println("Card 2 good to GO");
                        card2Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card2Suit.equalsIgnoreCase("Hearts")) {
                    try {
                        card2 = new PokerCards(PokerCards.Suit.Hearts, PokerCards.Number.valueOf(card2Num));
                        if (card1 == card2){
                            JFrame popUpError2 = new JFrame();
                            JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                    " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                        System.out.println("Card 2 good to GO");
                        card2Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card2Suit.equalsIgnoreCase("Spades")) {
                    try {
                        card2 = new PokerCards(PokerCards.Suit.Spades, PokerCards.Number.valueOf(card2Num));
                        if (card1 == card2){
                            JFrame popUpError2 = new JFrame();
                            JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                    " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                        System.out.println("Card 2 good to GO");
                        card2Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (card2Suit.equalsIgnoreCase("Clubs")) {
                    try {
                        card2 = new PokerCards(PokerCards.Suit.Clubs, PokerCards.Number.valueOf(card2Num));
                        if (card1 == card2){
                            JFrame popUpError2 = new JFrame();
                            JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                    " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                        System.out.println("Card 2 good to GO");
                        card2Good = true;
                    } catch (IllegalArgumentException e) {
                        JFrame popUpError2 = new JFrame();
                        JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Number Input for Second Card is incorrect! Please double check" +
                                " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JFrame popUpError2 = new JFrame();
                    JOptionPane.showMessageDialog(popUpError2, "Incorrect Input, Second Card's suit is incorrect! Please double check" +
                            " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                }

            }
            deck.shuffle();
            deck.shuffle();
            deck.shuffle();
            for (int i = 0; i < 52; i++){
                if (deck.cards[i].toString().equals(card1.toString())){
                    PokerDeck swapCards = new PokerDeck();
                    swapCards.cards[51] = deck.cards[i];
                    deck.cards[i] = deck.cards[0];
                    deck.cards[0] = swapCards.cards[51];


                }
            }
            for (int i = 0; i < 52; i++){
                if (deck.cards[i].toString().equals(card2.toString())){
                    PokerDeck swapCards = new PokerDeck();
                    swapCards.cards[50] = deck.cards[i];
                    deck.cards[i] = deck.cards[1];
                    deck.cards[1] = swapCards.cards[50];


                }
            }
            System.out.println("After swapping:");
            deck.printDeck(deck);
            System.out.println("User Player");
//            user.setCard2(card1);
//            user.setCard2(card2);
//            user.PrintHand();
            Player user = new Player();
            user.setCard1(card1);
            user.setCard2(card2);
            System.out.println(user.getCard1());
            System.out.println(user.getCard2());
            /*if(!(card1.toString().equals(card2.toString()))){
                try {
                    booleanCheck(numSelect, card1Good, card2Good);
                } catch (NullPointerException exception){
                    JFrame popUpError2 = new JFrame();
                    JOptionPane.showMessageDialog(popUpError2, "Your cares are the same! Please double check" +
                            " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }*/
            booleanCheck(numSelect, card1Good, card2Good);

        }

        if (a.getSource() == helpButton){
            helpFrame = new JFrame();
            //JFrame helpFrame = new JFrame();
            JPanel helpPanel = new JPanel();
            //helpPanel.setSize(800,1500);
            helpFrame.setSize(800,1500);
            helpFrame.setTitle("Help");
            //helpFrame.setLocationRelativeTo(null);
            helpFrame.setLocation(500,500);
            //helpPanel.setLocationRelativeTo(null);
            String royalFlush = "Royal Flush: Best hand in poker and is very rare. Same suit of the cards 10 to Ace";
            String StraightFlush = "Straight Flush: Second best hand, Just like a straight, but the cards are all the same suit.";
            String fourOfAKind = "Four of a Kind: Four of the same cards. Hand is completed with the highest card on the table or in your hand";
            String fullHouse = "Full House: A combination of three of a kind with a pair. The full house hand that has the highest three of a kind cards" +
                    " wins from other full houses";
            String flush = "Flush: Five cards that are all the same suit. These don't need to be in any order. If two players have a flush, the player" +
                    " with the highest card in the flush wins";
            String straight = "Straight: A series of five cards that follow each other, but that are not the same suit. Aces can follow a king, or start a straight" +
                    " followed by a two";
            String threeOfAKind = "Three of a Kind: Three cards of the same kind, for example three aces. The hand is completed with the two highest cards that are available";
            String twoPair = "Two Pair: Two sets of two cards of the same kind. For example two kings and two queens, the last card to complete the hand is the" +
                    " highest card that is left available";
            String Pair = "Pair: Two cards of the same kind, for example two aces. The hand is filled up with the three highest cards that are left available";
            String Highcard = "High card: You have none of the above hand patterns. Choose the highest card available rather in your hand or on the table";
            //JLabel textRF = new JLabel(royalFlush, SwingConstants.CENTER);
            JLabel textRF = new JLabel(royalFlush);
            JLabel textSF = new JLabel(StraightFlush, SwingConstants.CENTER);
            JLabel textFOAK = new JLabel(fourOfAKind,SwingConstants.CENTER);
            JLabel textFH = new JLabel(fullHouse, SwingConstants.CENTER);
            JLabel textFlush = new JLabel(flush, SwingConstants.CENTER);
            JLabel textStraight = new JLabel(straight, SwingConstants.CENTER);
            JLabel textTOAK = new JLabel(threeOfAKind, SwingConstants.CENTER);
            JLabel textTP = new JLabel(twoPair, SwingConstants.CENTER);
            JLabel textPair = new JLabel(Pair, SwingConstants.CENTER);
            JLabel textHighcard = new JLabel(Highcard, SwingConstants.CENTER);
            textRF.setFont(new Font("Serif", Font.PLAIN, 22));
            textSF.setFont(new Font("Serif", Font.PLAIN, 22));
            textFOAK.setFont(new Font("Serif", Font.PLAIN, 22));
            textFH.setFont(new Font("Serif", Font.PLAIN, 22));
            textFlush.setFont(new Font("Serif", Font.PLAIN, 22));
            textStraight.setFont(new Font("Serif", Font.PLAIN, 22));
            textTOAK.setFont(new Font("Serif", Font.PLAIN, 22));
            textTP.setFont(new Font("Serif", Font.PLAIN, 22));
            textPair.setFont(new Font("Serif", Font.PLAIN, 22));
            textHighcard.setFont(new Font("Serif", Font.PLAIN, 22));

            helpPanel.add(textRF);
            helpPanel.add(textSF);
            helpPanel.add(textFOAK);
            helpPanel.add(textFH);
            helpPanel.add(textFlush);
            helpPanel.add(textStraight);
            helpPanel.add(textTOAK);
            helpPanel.add(textTP);
            helpPanel.add(textPair);
            helpPanel.add(textHighcard);

            helpFrame.add(helpPanel);
            //helpFrame.pack();
            //helpFrame.setVisible(true);
            helpFrame.pack();
            helpFrame.setVisible(true);


            pack();

        }
    }


    /**
     * One last check to ensure the cards are not duplicates from user input
     * from actionPerformed()
     * @param //numSelect
     * @param //card1Good
     * @param //card2Good
     * @pre card1 boolean and card2boolean did not pass
     * @post no changes made
     */
    public void booleanCheck(String numbSelect, Boolean card1G, Boolean card2G){
        int count = 0;
        if((card1G && card2G)){
            if(card1.toString().equals(card2.toString())){
                //System.out.println("line 215");
                JFrame popUpError2 = new JFrame();
                JOptionPane.showMessageDialog(popUpError2, "Your cards are the same! Please double check" +
                        " your input", "ERROR", JOptionPane.ERROR_MESSAGE);
            } else {
                numSelect = textFieldPlayers.getText();
                int x = Integer.parseInt(numSelect.valueOf(numSelect));

                Player[] bots = new Player[x];
                while(count < x - 1){
                    bots[count] = new Player();
                    count++;
                }
                for (int i = 0; i < bots.length - 1; i++){
                    bots[i].setCard1(deck.drawCard());
                }
                for (int i = 0; i < bots.length - 1; i++){
                    bots[i].setCard2(deck.drawCard());
                }
                for(int i = 0; i < bots.length - 1; i++){
                    System.out.println("PLayer " + (i + 1));
                    System.out.println(bots[i].getCard1());
                    System.out.println(bots[i].getCard2());
                }
                PokerDeck swapCards = new PokerDeck();
                int playerCount = x * 2;
                for(int i = 0; i < x - 1; i++){
                    for (int j = 0; j < 52; j++){
                        if (deck.cards[j].toString().equals(bots[i].card1.toString())){
                            swapCards.cards[30] = deck.cards[j];
                            deck.cards[j] = deck.cards[playerCount - i];
                            deck.cards[playerCount - i] = swapCards.cards[30];


                        }
                        if (deck.cards[j].toString().equals(bots[i].card2.toString())){
                            swapCards.cards[29] = deck.cards[j];
                            deck.cards[j] = deck.cards[playerCount - (i - 1)];
                            deck.cards[playerCount - (i - 1)] = swapCards.cards[29];


                        }
                    }

                }
                System.out.println("POST");
                deck.printDeck(deck);

                callPokerTable(x);
            }
        }
    }

    public void callPokerTable(int n) {
        //table = new PokerTable(n);
        //pokerTableFrame();
        pokerTableFrame(n);
    }


    /**
     * The main page of the program/software
     * @pre callPokerTable() was called
     * @post no changes
     */
    //public void pokerTableFrame() {
    public void pokerTableFrame(int x){
        table = new PokerTable(x);
        askPage.setVisible(false);
        pokerTableFrame = new JFrame();
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();


        //pokerTableFrame.setLayout(new BorderLayout());
        pokerTableFrame.setLayout(new BorderLayout());
        GridLayout gl = new GridLayout(1,4);
        JPanel oddPanel = new JPanel();
        oddPanel.setLayout(gl);


        JTextPane textPane = new JTextPane();
        textPane.setText("Royal Flush %: \n" + "Straight Flush %: \n" + "Four of a Kind %: \n" +
                "Full House %: \n" + "Flush %: \n" + "Straight %: \n" + "Three of a Kind %: \n" +
                "Two Pair %: \n" + "Pair %: \n" + "High Card %: ");
        textPane.setFont(new Font("Serif", Font.PLAIN, 20));
        oddPanel.add(textPane);

        //buttons new game and try a new hand (lower right)
        //JPanel buttonPane = new JPanel();
        //JPanel helpPane = new JPanel();
        //buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

        helpButton = new JButton("Help");
        helpButton.setFont(new Font("Arial", Font.PLAIN, 30));
        helpButton.setPreferredSize(new Dimension(200,200));
        //helpButton.setSize(200,200);
        //buttonPane.add(helpButton);
        oddPanel.add(helpButton);
        newGame = new JButton("New Game");
        newGame.setFont(new Font("Arial", Font.PLAIN, 30));
        newGame.setPreferredSize(new Dimension(200,200));
        //buttonPane.add(newGame);
        oddPanel.add(newGame);
        newHand = new JButton("Try a New Hand");
        newHand.setFont(new Font("Arial", Font.PLAIN,30));
        newHand.setPreferredSize(new Dimension(200,200));
        //buttonPane.add(newHand);
        oddPanel.add(newHand);
        //pokerTableFrame.add(buttonPane, BorderLayout.SOUTH);
        pokerTableFrame.add(oddPanel, BorderLayout.SOUTH);



        //lambda expression
        newGame.addActionListener(event -> table.poker.startPoker());
        newHand.addActionListener(event -> new PokerFrameDumb());
        newHand.addActionListener(event -> pokerTableFrame.setVisible(false));   //closes the table page
        helpButton.addActionListener(this);
        //helpButton.addActionListener(hb);
        //helpButton.addActionListener(event -> PokerFrameDumb.help);
        //helpFrame.setLocationRelativeTo(null);
        //helpFrame.setSize(800, 1500);


        //add(table);

        //System.out.println("Poker Frame Dumb 439");
        //String icon1s = Poker.flop1.toString();
        //ImageIcon iconf1 = new ImageIcon("Poker2/poker/one/images" + Poker.flop1.toString() + ".png");
        //ImageIcon iconf1 = new ImageIcon(Poker.flop1.toString() + ".png");
        //getContentPane().add((Component) icon);
        JLabel icon1s = new JLabel();
        //icon1s.setIcon(icon);
        //pokerTableFrame.add(iconf1);

        /*try {
            //ImageIcon backDeckBack = new ImageIcon(Objects.requireNonNull(getClass().getResource("Deck.BACK.jpg")));
            //JLabel firstCardSpot = new JLabel(backDeckBack);
            //pokerTableFrame.add(firstCardSpot);
            BufferedImage firstcardSpot = ImageIO.read(new File("Card_BACK.jpg"));

            //pokerTableFrame.add(firstcardSpot);
        } catch (NullPointerException | IOException exception){
            exception.printStackTrace();
        }*/


        //pokerTableFrame.add(new JLabel(new ImageIcon("/poker/one/images/" + Poker.flop1.toString() + ".png")));
        //pokerTableFrame.add(new JLabel((Icon) ImageIO.read(Objects.requireNonNull(getClass().getResource("\\poker\\one\\images\\" + Poker.flop1.toString() + ".png")))));
        //BufferedImage f1 = ImageIO.read((getClass().getResource("/poker/one/images" + Poker.flop1.toString() + ".png")));
        //Image img = ImageIO.read(new File(String.valueOf(getClass().getResource("/poker/one/images/" + Poker.flop1.toString() + ".png"))));
        //Image imag = new ImageIcon("/poker/one/images/" + Poker.flop1.toString() + ".png").getImage();
        //setIconImage(imag);
        //pokerTableFrame.add(new JLabel((Icon) ImageIO.read(getClass().getResource("/poker/one/images" + Poker.flop1.toString() + ".png"))));
        //pokerTableFrame.add(ImageIO.read(new File("\\poker\\one\\images" + Poker.flop1.toString() + ".png")));
        //add((Component) f1);


        //add(table);
        pokerTableFrame.add(table);
        pack();
        pokerTableFrame.setSize(screensize.width, screensize.height - 50);
        pokerTableFrame.setTitle("Poker Hands Calculator");
        pokerTableFrame.setVisible(true);
        pokerTableFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }



    public static void main(String[] args) throws NullPointerException{
        new PokerFrameDumb();
    }
}
