package test.Poker2.poker.one.testing;

import test.Poker2.poker.one.testing.Poker;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class PokerTable extends JComponent {
    public Poker poker;
    private int numPlay = 0;
    public static int cardsRevealNum = 0;
    private static boolean gameOver;
    //PopUp window;
    String path = "Poker\\GreenTable.jpg";

    /*public String[] getPID(){

    }*/


    public boolean getGameOver(){
        return gameOver;
    }

    //constructor
    //public PokerTable(int players, PokerCards card1, PokerCards card2){
    public PokerTable(int players){
        numPlay = players;
        setPreferredSize(new Dimension(1000,720));
        addMouseListener(new PlayHandler());
        gameOver = false;
        repaint();
        poker = new Poker(numPlay);
        //freeCall();
    }



    private class PlayHandler extends MouseAdapter {
        @Override
        public void mouseClicked(MouseEvent event) {
            //boolean bool = cardReveal(); //calls cardReveal where the number of cards revealed is incremented
            System.out.println("PokerTable 47");
            /*if (bool == true) {
                if (cardsRevealNum == 4) {  //once all cards are reveal, start a new game
                    gameOver = true;
                    repaint();
                } else {
                    gameOver = false;
                    repaint();
                }
            }*/

        }
    }



    public static boolean cardReveal(){
        cardsRevealNum++; // clicks to see the next reveal
        return false;
    }

    public void resetGame(){
        //shuffle cards here
        //this.poker;
        gameOver = false;
        repaint();
    }


    public void paintComponent(Graphics g){
        System.out.println("PokerTable 71");
        super.paintComponents(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(Color.green);
        /*Image image = new ImageIcon("/poker/one/images/" + Poker.flop1.toString() + ".png").getImage();
        ((Graphics2D) g).drawImage(image,0,0,null);*/

        try{
            BufferedImage bgTable = ImageIO.read(new File("GreenTable.jpg"));
            g.drawImage(bgTable,0,0,null);
            //Graphics2D g2 = (Graphics2D) g;

        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}
